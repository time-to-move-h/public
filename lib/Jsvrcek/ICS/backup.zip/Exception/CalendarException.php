<?php

namespace Jsvrcek\ICS\Exception;

class CalendarException extends \Exception
{
}
