<?php

namespace Jsvrcek\ICS\Exception;

class CalendarRecurrenceException extends CalendarException
{
}
