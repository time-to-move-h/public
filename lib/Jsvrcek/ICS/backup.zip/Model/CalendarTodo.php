<?php

namespace Jsvrcek\ICS\Model;

class CalendarTodo
{
}
