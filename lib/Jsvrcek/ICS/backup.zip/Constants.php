<?php
namespace Jsvrcek\ICS;

class Constants
{
    const CRLF = "\r\n";
}
